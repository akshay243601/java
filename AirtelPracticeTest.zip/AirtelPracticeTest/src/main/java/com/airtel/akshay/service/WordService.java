package com.airtel.akshay.service;

import org.springframework.stereotype.Service;

import com.airtel.akshay.modal.ResponseStatus;

@Service
public interface WordService {

	public ResponseStatus getCommonData(String[] files);

}
