package com.airtel.akshay.repository;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.stereotype.Repository;

import com.airtel.akshay.exception.CustomException;
import com.airtel.akshay.modal.ResponseStatus;
import com.airtel.akshay.utils.CommonUtils;

@Repository
public class WordRepositoryImpl implements WordRepository {

	@Override
	public ResponseStatus getCommonWords(String[] files) throws Exception {
		ResponseStatus response = new ResponseStatus();
		response.setSucess(true);
		response.setMessage("success");
		if(!validateFiles(files)) {
			response.setSucess(false);
			response.setMessage("One or more files are not having valid path");
			return response;
		}
		
		ExecutorService executor = Executors.newFixedThreadPool(3);
		ConcurrentHashMap<String, Set<String>> fileMap = new ConcurrentHashMap<String, Set<String>>();
		for (String file : files) {
			Thread t = new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						readDataFromFile(file, fileMap);
					} catch (Exception e) {
						response.setSucess(false);
						response.setMessage(e.getMessage());
					}
				}
			});
			executor.submit(t);
		}

		executor.shutdown();

		while (!executor.isTerminated()) {
		}

		List<String> words = new ArrayList<String>();
		if (fileMap.size() > 1) {
			Set<String> wordInFile = fileMap.remove(files[0]);

			for (String w : wordInFile) {
				int count = 0;
				for (Set<String> vals : fileMap.values()) {
					if (!vals.contains(w)) {
						break;
					}
					count++;
					if (count == fileMap.size())
						words.add(w);
				}
			}

		}
		System.out.println(words);
		response.setData(words);
		return response;
	}

	private static void readDataFromFile(String filePath, ConcurrentHashMap<String, Set<String>> fileMap)
			throws Exception {
		Set<String> set = new HashSet<String>();
		if (CommonUtils.isFileExist(filePath)) {
			FileInputStream inputStream = null;
			Scanner sc = null;
			try {
				if (fileMap.contains(filePath)) {
					return;
				}
				fileMap.put(filePath, set);

				// using Stream so that file object will not contain whole fileData. It will
				// process line by line.
				inputStream = new FileInputStream(filePath);
				sc = new Scanner(inputStream, "UTF-8");
				while (sc.hasNextLine()) {
					String vals[] = sc.nextLine().split(" ");

					ArrayList<String> a = new ArrayList<>();
					for (String val : vals) {
						// Fetch valuable string and replace special character from string
						val = CommonUtils.getWord(val);
						if (val != null && val.length() > 0) {
							set.add(val.toLowerCase());
						}
					}
				}
				if (sc.ioException() != null) {
					throw sc.ioException();
				}
			} catch (Exception e) {
				throw e;
			} finally {
				if (inputStream != null) {
					inputStream.close();
				}
				if (sc != null) {
					sc.close();
				}
			}
		} else {
			throw new CustomException("File not found.");
		}
	}

	private boolean validateFiles(String[] files) {
		for (String filePath : files) {
			if (!CommonUtils.isFileExist(filePath)) {
				return false;
			}
		}
		return true;
	}

}
