package com.airtel.akshay.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airtel.akshay.exception.CustomException;
import com.airtel.akshay.modal.ResponseStatus;
import com.airtel.akshay.repository.WordRepository;

@Service
public class WordServiceImpl implements WordService {

	@Autowired
	public WordRepository wordRepository;

	@Override
	public ResponseStatus getCommonData(String[] files) {
		try {
			return wordRepository.getCommonWords(files);
		} catch (Exception e) {
			return new ResponseStatus(e.getMessage(), false);
		}
	}

}
