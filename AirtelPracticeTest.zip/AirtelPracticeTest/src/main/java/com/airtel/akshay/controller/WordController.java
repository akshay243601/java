package com.airtel.akshay.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.airtel.akshay.modal.ResponseStatus;
import com.airtel.akshay.service.WordService;


@RestController
@RequestMapping("/word")
public class WordController {

	@Autowired
	public WordService wordService;
	
    @RequestMapping(value="/findCommonWord", method = RequestMethod.GET, produces = "application/json")
	public ResponseStatus getCommonData(@RequestParam("files") String[] files){
		return wordService.getCommonData(files);
	}

    @RequestMapping(method = RequestMethod.GET)
	public String getCommonData1(){
		return "HELLO";
	}
}
