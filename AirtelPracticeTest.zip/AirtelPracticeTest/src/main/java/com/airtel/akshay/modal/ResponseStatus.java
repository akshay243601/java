package com.airtel.akshay.modal;

public class ResponseStatus {
	private String message;
	private boolean isSucess;
	private Object data;
	
	
	public ResponseStatus() {
		super();
	}
	
	public ResponseStatus(String message, boolean isSucess) {
		super();
		this.message = message;
		this.isSucess = isSucess;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isSucess() {
		return isSucess;
	}
	public void setSucess(boolean isSucess) {
		this.isSucess = isSucess;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}
	
	
	
}
