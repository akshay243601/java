package com.airtel.akshay.repository;

import org.springframework.stereotype.Repository;

import com.airtel.akshay.modal.ResponseStatus;

@Repository
public interface WordRepository {
	ResponseStatus getCommonWords(String[] files) throws Exception;
}
