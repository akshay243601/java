package com.airtel.akshay.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.airtel.akshay.exception.CustomException;

public class CommonUtils {
	
	public static String getWord(String value) {
		String val = "";
		if (value != null && value.length() > 0) {
			val = value.replaceAll("[^A-Za-z0-9]", "");
		}
		return val;
	}

	public static boolean isFileExist(String filePath) {
		return new File(filePath).exists();
	}

}
