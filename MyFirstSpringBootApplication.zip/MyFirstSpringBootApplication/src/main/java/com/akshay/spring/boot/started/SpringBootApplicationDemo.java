package com.akshay.spring.boot.started;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootApplicationDemo {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootApplicationDemo.class, args);
	}
}
